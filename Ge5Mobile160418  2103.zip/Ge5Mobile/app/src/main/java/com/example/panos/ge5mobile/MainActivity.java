package com.example.panos.ge5mobile;

//import android.app.FragmentManager;
import android.graphics.Color;
import android.location.Location;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.Gravity;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.FirebaseDatabase;

import static android.view.View.FOCUS_BACKWARD;



import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;



public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    Button btnGetLoc;
    Button btnX;
    ConstraintLayout ConLaytest;

    MenuItem test_menu_item;



    NavigationView testnav  ;
    DrawerLayout  testdraw;
    public static boolean emfanise=true;
    View test_x;

    public  static Integer xristis=0;

    public DrawerLayout drawer1;
    public static View viewdrawer1root;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //panos 03-04-2018
        //NavigationView testnav= (NavigationView) findViewById(R.id.nav_view);
        testnav=  findViewById(R.id.nav_view);
        testdraw=   findViewById(R.id.drawer_layout);
        //end panos 03-04-2018

        //panos 04-04-2018 eskase sos!!!
        ConLaytest =findViewById(R.id.frameLayout);

        //panos 04-04-2018

        //panos 06-04-2018  disappear maap and left side menu
        //View test_x = findViewById(R.id.include_id);   //leitourgouse kai evala to view epanw
        View test_x = findViewById(R.id.include_id);   //08-04-2018 end
        //test_x.setVisibility(View.INVISIBLE);  //test gia ligo 08-04-2017




        //test_x.setVisibility(View.GONE);   // 13-04-18 original
        test_x.setVisibility(View.VISIBLE);   // 13-04-18 allagi

        //emfanise = false;      // 13-04-18 original
        emfanise = true;       // 13-04-18 allagi
        //end panos 06-04-2018


        //dokimi panos 09-04-2018
         drawer1 = (DrawerLayout) findViewById(R.id.drawer_layout);
         viewdrawer1root = drawer1.getRootView();
        // end dokimi panos 09-04-2018

        btnGetLoc = (Button) findViewById(R.id.btnGetLoc);   //03-04-2018

        btnGetLoc.setVisibility(View.GONE);  //13-04-2018  mono gia ligo
        // PROS GEORGE SKIKO TO btnGetLoc.setOnClickListener(new View.OnClickListener()  EINAI AKYRO
        // OYSIASTIKA DEN YPARXEI
        btnGetLoc.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                  Toast.makeText(MainActivity.this, ""+"get location click start", Toast.LENGTH_SHORT).show();
                //TEST 09-04-18
                ContactUsFragment contactUsFragment = new ContactUsFragment(); //arxiko
                FragmentManager manager = getSupportFragmentManager();
                manager.beginTransaction().replace(R.id.mainLayout, contactUsFragment).commit();

                emfanise=true;
                View test_x = findViewById(R.id.include_id);
                test_x.setVisibility(View.VISIBLE);

                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
                //return true;

                //END TEST 09-04-18

       //  start merge with real gps loacation and trace path  11-04-2018
       // get location when click button and  the journey begins....
                GPSTracker g = new GPSTracker(getApplicationContext());
                Location l= g.getLocation();
                //Toast.makeText(getApplicationContext(), "mesa sto main meta thn synartisi l null??? ", Toast.LENGTH_LONG).show();

                if (l !=null) {
                    //double lat = l.getAltitude();
                    //Toast.makeText(getApplicationContext(), "mesa sto main meta thn synartisi oxi null to l ", Toast.LENGTH_LONG).show();
                    final double lat = l.getLatitude();
                    final double lon = l.getLongitude();

                    Toast.makeText(MainActivity.this, "current location yparxei "+lat,  Toast.LENGTH_SHORT).show();   //remove 260318
                    //mDatabase = FirebaseDatabase.getInstance().getReference();
                    //mMessageReference = FirebaseDatabase.getInstance().getReference("messagexx");
                    //mDatabase.child("title").setValue("sto click apo button");
                    //mDatabase.child("main activity").setValue(l);

                }
                else{
                    Toast.makeText(MainActivity.this, "current location  = null " , Toast.LENGTH_SHORT).show();   //remove 260318
                }



       // end   start merge with real gps loacation and trace path  11-04-2018



            } //END ONCLICK




        });


        // PROS GEORGE SKIKO TO btnGetLoc.setOnLongClickListener(new View.OnClickListener()  EINAI AKYRO
        // OYSIASTIKA DEN YPARXEI
        btnGetLoc.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(MainActivity.this, ""+"LONG click getlocation START", Toast.LENGTH_SHORT).show();
                emfanise=true;
                View test_x = findViewById(R.id.include_id);
                test_x.setVisibility(View.VISIBLE);

                btnGetLoc.setVisibility(View.GONE);  //08-04-2018
                return true;
            }
        });








        // PROS GEORGE SKIKO  EPILEGEIS XRHSTH APO TO BUTTON UPPER LEFT KAI META
        // AFOY EPILEXEIS TO BUTTON EXAFANIZETAI
        btnX = (Button) findViewById(R.id.buttonx);   //03-04-2018
        btnX.setOnClickListener(new View.OnClickListener() {
            //btnGetLoc.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Toast.makeText(MainActivity.this, ""+"select user click = buttonXxxx", Toast.LENGTH_SHORT).show();
               // view.setVisibility(View.INVISIBLE);  // mono to koumpi xalaei



                //good luck


                //end good luck

                ContactUsFragment contactUsFragment = new ContactUsFragment();
                FragmentManager manager = getSupportFragmentManager();
                manager.beginTransaction().replace(R.id.mainLayout, contactUsFragment).commit();



                //View test_x = findViewById(R.id.include_id);
                //test_x.setVisibility(View.INVISIBLE);
                //emfanise = false;



                //06-04-2018
                //final PopupMenu popupMenu = new PopupMenu(MainActivity.this, buttonX);
                //final PopupMenu popupMenu = new PopupMenu(MainActivity.this, (View) item);
                //DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                //btnGetLoc = (Button) findViewById(R.id.btnGetLoc);   //03-04-2018

                //item nav_man =  findViewById(R.id.nav_manage);

                final PopupMenu popupMenu;
                popupMenu = new PopupMenu(MainActivity.this, btnX);   //
                popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());

                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                    @Override
                    public boolean onMenuItemClick(MenuItem menuItem) {

                        switch (menuItem.getItemId()){
                            case  R.id.one:
                                Toast.makeText(MainActivity.this, ""+"Χ Ρ Η Σ Τ Η Σ  1", Toast.LENGTH_SHORT).show();
                                xristis=1;
                                btnX.setVisibility(View.GONE); //added 06-04-18

                                return true;
                            case R.id.two:
                                Toast.makeText(MainActivity.this, ""+"Χ Ρ Η Σ Τ Η Σ  2", Toast.LENGTH_SHORT).show();
                                btnX.setVisibility(View.GONE); //added 06-04-18
                                xristis=2;


                                return true;
                            case R.id.three:
                                Toast.makeText(MainActivity.this, ""+"Χ Ρ Η Σ Τ Η Σ  3", Toast.LENGTH_SHORT).show();
                                btnX.setVisibility(View.GONE); //added 06-04-18
                                xristis=3;
                                return true;
                        }


                        return true;

                    }



                });


                popupMenu.show();


            //06-04-2018  end




            }

        });






    }





    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

       //16-4-18

        if  (id==R.id.user_1){
            Toast.makeText(MainActivity.this, "EPITELOUS MARIA",  Toast.LENGTH_SHORT).show();
            return  true;
        }
        if  (id==R.id.user_2){
            Toast.makeText(MainActivity.this, "EPITELOUS Nick",  Toast.LENGTH_SHORT).show();
            return  true;
        }
        if  (id==R.id.user_3){
            Toast.makeText(MainActivity.this, "EPITELOUS David",  Toast.LENGTH_SHORT).show();
            return  true;
        }
        if  (id==R.id.user_4){
            Toast.makeText(MainActivity.this, "EPITELOUS George",  Toast.LENGTH_SHORT).show();
            return  true;
        }
        if  (id==R.id.user_5){
            Toast.makeText(MainActivity.this, "John",  Toast.LENGTH_SHORT).show();
            return  true;
        }
        //16-4-18

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();



        //15-04-18
        //int id = item.getItemId();
        //test_menu_item = (MenuItem) findViewById(R.id.sel_user);
        //test_menu_item.setEnabled(false); //skazei

        // menu.getItem(1).setEnabled(false);
        //R.id.sel_user

        // 15-04-18


               // PROS GEORGE SKIKO DOKIMIH         if (id == R.id.sel_user)  DEN EXEI KAPOIO ROLO

        if (id == R.id.sel_user) {
            // select user

            //  start merge with real gps loacation and trace path  11-04-2018
            // get location when click button and  the journey begins....
            GPSTracker g = new GPSTracker(getApplicationContext());
            Location l= g.getLocation();
            //Toast.makeText(getApplicationContext(), "mesa sto main meta thn synartisi l null??? ", Toast.LENGTH_LONG).show();

            if (l !=null) {
                //double lat = l.getAltitude();
                //Toast.makeText(getApplicationContext(), "mesa sto main meta thn synartisi oxi null to l ", Toast.LENGTH_LONG).show();
                final double lat = l.getLatitude();
                final double lon = l.getLongitude();

                Toast.makeText(MainActivity.this, "current location yparxei "+lat,  Toast.LENGTH_SHORT).show();   //remove 260318
                //mDatabase = FirebaseDatabase.getInstance().getReference();
                //mMessageReference = FirebaseDatabase.getInstance().getReference("messagexx");
                //mDatabase.child("title").setValue("sto click apo button");
                //mDatabase.child("main activity").setValue(l);






            }
            else{
                Toast.makeText(MainActivity.this, "current location  = null " , Toast.LENGTH_SHORT).show();   //remove 260318
            }


            //Toast.makeText(MainActivity.this, "current location "+ +Math.floor(lat1*100000)/100000+" "+Math.floor(lon1*100000)/100000), Toast.LENGTH_SHORT).show();   //remove 260318
            //mCurrentLocation.setText("User Location "+Math.floor(lat*100000)/100000+" "+Math.floor(lon*100000)/100000);  //230318


            // end   start merge with real gps loacation and trace path  11-04-2018



        }

        // PROS GEORGE SKIKO DOKIMIH         else if (id == R.id.sel_problems) { DEN EXEI KAPOIO ROLO
        else if (id == R.id.sel_problems) {

            //08-04-2018  ΜΕΝΟΥ ΒΛΑΒΩΝ
            //test_x.setVisibility(View.VISIBLE);
            Toast.makeText(MainActivity.this, "αρχη ΕΠΙΛΟΓΗ ΒΛΑΒΩΝ", Toast.LENGTH_SHORT).show();
            final PopupMenu popupMenu;
            //PopupMenu popupMenupro = new PopupMenu(MainActivity.this, test_x );

            // DOULEYEI ALLA DEN EFMANIZEI TIPOTA
            //PopupMenu popupMenupro = new PopupMenu(MainActivity.this, testnav );
            //popupMenupro.getMenuInflater().inflate(R.menu.problems_popup, popupMenupro.getMenu());
//            popupMenupro.show();// den skazei ALLA DEN EMFANIZEI TIPOTA
          // END DOULEYEI ALLA DEN EFMANIZEI TIPOTA


            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            PopupMenu popupMenupro = new PopupMenu(MainActivity.this, drawer );
            popupMenupro.getMenuInflater().inflate(R.menu.problems_popup, popupMenupro.getMenu());
            popupMenupro.show();// den skazei ALLA DEN EMFANIZEI TIPOTA



            popupMenupro.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {

                    switch (menuItem.getItemId()){
                        case  R.id.one:
                            Toast.makeText(MainActivity.this, ""+"blavi  1", Toast.LENGTH_SHORT).show();


                            return true;
                        case R.id.two:
                            Toast.makeText(MainActivity.this, ""+"blavi  2", Toast.LENGTH_SHORT).show();


                            return true;
                        case R.id.three:
                            Toast.makeText(MainActivity.this, ""+"blavi  3", Toast.LENGTH_SHORT).show();

                            return true;
                    }


                    return true;

                }






            });



            popupMenupro.show();
            Toast.makeText(MainActivity.this, "ΤΕΛΟΣ ΕΠΙΛΟΓΗ ΒΛΑΒΩΝ", Toast.LENGTH_SHORT).show();




                //END 08-04-2018 ΜΕΝΟΥ ΒΛΑΒΩΝ




        }

        // PROS GEORGE SKIKO EDW START THE APP TO TRACE AUTOMATICALLY THE PATH AND SAVE TO FIREBASE
        else if (id == R.id.cur_location) {


            //12-04-18  DOKIMI
            GPSTracker g = new GPSTracker(getApplicationContext());
            Location l= g.getLocation();
            //Toast.makeText(getApplicationContext(), "mesa sto main meta thn synartisi l null??? ", Toast.LENGTH_LONG).show();

            if (l !=null) {
                /*double lat = l.getAltitude(); */
                //Toast.makeText(getApplicationContext(), "mesa sto main meta thn synartisi oxi null to l ", Toast.LENGTH_LONG).show();
                final double lat = l.getLatitude();
                final double lon = l.getLongitude();

                Toast.makeText(MainActivity.this, "apo menou current location yparxei "+lat,  Toast.LENGTH_SHORT).show();   //remove 260318

                LatLng pp = new LatLng(lat,lon);
                MarkerOptions option = new MarkerOptions();
                option.position(pp).title("current location first marker");
                ContactUsFragment.map.addMarker(option);
                ContactUsFragment.map.getMaxZoomLevel(); //diko mou
                ContactUsFragment.map.moveCamera(CameraUpdateFactory.newLatLng(pp));
                ContactUsFragment.map.animateCamera(CameraUpdateFactory.newLatLng(pp));  //diko mou

                ContactUsFragment.map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lon), 22));














            }
            else{
                Toast.makeText(MainActivity.this, "apo menou current location  = null " , Toast.LENGTH_SHORT).show();   //remove 260318
            }






            //ενδ 12-04-18



        } else if (id == R.id.nav_manage) {



        }

       // PROS GEORGE SKIKO DOKIMI DEN PAIZEI KAPOIO ROLO
         else if (id == R.id.nav_share) {

            // good luck 03-04-2018
            //buttonX.setVisibility(View.INVISIBLE); //added 250318 night
            btnGetLoc.setVisibility(View.VISIBLE);
            testnav.setBackgroundColor(Color.BLUE);
            testdraw.setBackgroundColor(Color.RED);

            View test_x = findViewById(R.id.include_id);  // exafanizei to menu afou prwta to kanei mple
            test_x.setVisibility(View.INVISIBLE);
            emfanise = false;



        }
    // PROS GEORGE SKIKO DOKIMI HTAN TO PALAIO START DEN PAIZEI KAPOIO ROLO
        else if (id == R.id.start_app) {

            //added according to youtube video 03-04-2018
            ContactUsFragment contactUsFragment = new ContactUsFragment(); //arxiko
            FragmentManager manager = getSupportFragmentManager();
            manager.beginTransaction().replace(R.id.mainLayout, contactUsFragment).commit();

            emfanise=true;
            // end 03-04-2018




        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
